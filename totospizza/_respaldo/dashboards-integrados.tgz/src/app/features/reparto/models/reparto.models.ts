import type { EstadoEntrega } from '../../../core/models/api';

export interface ProductoEntregaItem {
  readonly cantidad: number;
  readonly nombre: string;
}

/** Tarjeta de una entrega del motorizado (sale de EntregaAsignadaResponse del backend). */
export interface EntregaAsignada {
  readonly id: number;
  readonly ordenNumero: string;
  readonly codigoPedido: string;
  readonly estado: EstadoEntrega;
  readonly horaInfoSuperior: string;
  readonly clienteNombre: string;
  readonly clienteTelefono: string;
  readonly direccion: string;
  readonly referencia: string;
  readonly instrucciones: string | null;
  readonly productos: readonly ProductoEntregaItem[];
  readonly distanciaKm: number | null;
  readonly mapaUrl: string;
}

import { ChangeDetectionStrategy, Component, DestroyRef, computed, inject, signal } from '@angular/core';
import { finalize } from 'rxjs';
import { peticionSilenciosa } from '../../../core/interceptors/http-context';
import type { EntregaAsignadaResponse } from '../../../core/models/api';
import { AuthService } from '../../../core/services/auth.service';
import { OperacionApi } from '../../../core/services/api/operacion.api';
import { ToastService } from '../../../core/services/toast.service';
import { esApiException, mensajeDeError } from '../../../core/utils/api-exception';
import { formatearHora } from '../../../core/utils/fechas';
import type { EntregaAsignada } from '../models/reparto.models';

const REFRESCO_MS = 20_000;

/**
 * Entregas del motorizado: sale a reparto y confirma cada entrega con el PIN de 4 dígitos del cliente.
 */
@Component({
  selector: 'app-reparto-panel',
  templateUrl: './reparto-panel.component.html',
  styleUrls: ['./reparto-panel.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class RepartoPanelComponent {
  private readonly api = inject(OperacionApi);
  private readonly toast = inject(ToastService);
  private readonly auth = inject(AuthService);

  private readonly datos = signal<readonly EntregaAsignadaResponse[]>([]);
  protected readonly cargando = signal(true);
  protected readonly sinConexion = signal(false);
  protected readonly ocupado = signal<number | null>(null);

  // Confirmación con PIN
  protected readonly paraConfirmar = signal<EntregaAsignada | null>(null);
  protected readonly pin = signal('');
  protected readonly errorPin = signal<string | null>(null);

  protected readonly motorizadoNombre = computed(() => {
    const u = this.auth.usuario();
    return u ? `${u.nombres.split(' ')[0]} ${u.apellidos.split(' ')[0]}` : '';
  });
  protected readonly entregas = computed(() => this.datos().map(aTarjeta));
  protected readonly totalAsignadas = computed(() => this.entregas().length);
  protected readonly totalEnCamino = computed(() => this.entregas().filter((e) => e.estado === 'EN_CAMINO').length);
  protected readonly totalPorSalir = computed(() => this.entregas().filter((e) => e.estado === 'ASIGNADA').length);
  protected readonly entregaActivaEnCamino = computed(() => this.entregas().find((e) => e.estado === 'EN_CAMINO') ?? null);

  constructor() {
    this.cargar(false);
    const id = setInterval(() => !document.hidden && this.cargar(true), REFRESCO_MS);
    inject(DestroyRef).onDestroy(() => clearInterval(id));
  }

  protected reintentar(): void {
    this.cargar(false);
  }

  protected salirAReparto(entrega: EntregaAsignada): void {
    const activa = this.entregaActivaEnCamino();
    if (activa) {
      this.toast.warning('Termina tu entrega actual', `Completa el pedido ${activa.codigoPedido} antes de salir con otro.`);
      return;
    }
    if (this.ocupado() !== null) return;
    this.ocupado.set(entrega.id);
    this.api
      .iniciarRuta(entrega.id)
      .pipe(finalize(() => this.ocupado.set(null)))
      .subscribe({
        next: () => {
          this.toast.success('¡En camino!', `Saliste con el pedido ${entrega.codigoPedido}.`);
          this.cargar(true);
        },
        error: () => this.cargar(true),
      });
  }

  protected abrirConfirmacion(entrega: EntregaAsignada): void {
    this.paraConfirmar.set(entrega);
    this.pin.set('');
    this.errorPin.set(null);
  }

  protected escribirPin(evento: Event): void {
    const campo = evento.target as HTMLInputElement;
    const digitos = campo.value.replace(/\D/g, '').slice(0, 4);
    campo.value = digitos;
    this.pin.set(digitos);
    this.errorPin.set(null);
  }

  protected confirmarEntrega(): void {
    const entrega = this.paraConfirmar();
    if (!entrega || this.ocupado() !== null) return;
    if (!/^\d{4}$/.test(this.pin())) {
      this.errorPin.set('El código tiene 4 dígitos.');
      return;
    }
    this.ocupado.set(entrega.id);
    this.api
      .confirmarEntrega(entrega.id, { codigoPin: this.pin() }, { context: peticionSilenciosa() })
      .pipe(finalize(() => this.ocupado.set(null)))
      .subscribe({
        next: () => {
          this.paraConfirmar.set(null);
          this.datos.update((l) => l.filter((e) => e.entregaId !== entrega.id));
          this.toast.success('Entrega confirmada', `${entrega.codigoPedido} quedó entregado.`);
        },
        error: (e: unknown) => {
          // PIN incorrecto o bloqueado: el mensaje va dentro del modal
          this.errorPin.set(mensajeDeError(e, 'No pudimos confirmar la entrega.'));
          if (esApiException(e) && e.codigo === 'PIN_BLOQUEADO') this.cargar(true);
        },
      });
  }

  protected cerrarConfirmacion(): void {
    if (this.ocupado() === null) this.paraConfirmar.set(null);
  }

  private cargar(silencioso: boolean): void {
    this.api
      .misEntregas(silencioso ? { context: peticionSilenciosa() } : undefined)
      .pipe(finalize(() => this.cargando.set(false)))
      .subscribe({
        next: (lista) => {
          this.datos.set(lista);
          this.sinConexion.set(false);
        },
        error: () => this.sinConexion.set(true),
      });
  }
}

function aTarjeta(e: EntregaAsignadaResponse, indice: number): EntregaAsignada {
  const { direccion } = e;
  return {
    id: e.entregaId,
    ordenNumero: `Orden ${String(indice + 1).padStart(2, '0')}`,
    codigoPedido: `#${e.numeroPedido}`,
    estado: e.estado,
    horaInfoSuperior: `Asignada · ${formatearHora(e.asignadaEn)}`,
    clienteNombre: e.nombreCliente,
    clienteTelefono: e.telefonoCliente,
    direccion: `${direccion.direccion}, ${direccion.distrito}`,
    referencia: direccion.referencia ?? '',
    instrucciones: e.instrucciones,
    productos: (e.items ?? []).map((i) => ({ cantidad: i.cantidad, nombre: i.nombre })),
    distanciaKm: e.distanciaKm,
    mapaUrl: `https://www.google.com/maps/dir/?api=1&destination=${direccion.latitud},${direccion.longitud}`,
  };
}

import { ChangeDetectionStrategy, Component, DestroyRef, computed, inject, signal } from '@angular/core';
import { finalize } from 'rxjs';
import { peticionSilenciosa } from '../../../core/interceptors/http-context';
import type { EmpleadoResponse, PedidoListoResponse } from '../../../core/models/api';
import { OperacionApi } from '../../../core/services/api/operacion.api';
import { ToastService } from '../../../core/services/toast.service';
import { formatearHora } from '../../../core/utils/fechas';
import type { PedidoListoMostrador } from '../models/mostrador.models';

const REFRESCO_MS = 15_000;
type Filtro = 'TODOS' | 'DELIVERY' | 'RECOJO';

/**
 * Mostrador del despachador: pedidos listos de su sede.
 * Delivery → asigna un motorizado disponible. Recojo → entrega al cliente en el mostrador.
 */
@Component({
  selector: 'app-mostrador-panel',
  templateUrl: './mostrador-panel.component.html',
  styleUrls: ['./mostrador-panel.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class MostradorPanelComponent {
  private readonly api = inject(OperacionApi);
  private readonly toast = inject(ToastService);

  private readonly datos = signal<readonly PedidoListoResponse[]>([]);
  protected readonly cargando = signal(true);
  protected readonly sinConexion = signal(false);
  protected readonly filtroTipo = signal<Filtro>('TODOS');
  protected readonly ocupado = signal(false);

  // Modal de asignación (delivery) y de entrega en mostrador (recojo)
  protected readonly paraAsignar = signal<PedidoListoMostrador | null>(null);
  protected readonly paraEntregar = signal<PedidoListoMostrador | null>(null);
  protected readonly motorizados = signal<readonly EmpleadoResponse[]>([]);
  protected readonly cargandoMotorizados = signal(false);
  protected readonly motorizadoElegido = signal<number | null>(null);

  protected readonly pedidos = computed(() => this.datos().map(aFila));
  protected readonly totalDelivery = computed(() => this.pedidos().filter((p) => p.tipoEntrega === 'DELIVERY').length);
  protected readonly totalRecojo = computed(() => this.pedidos().filter((p) => p.tipoEntrega === 'RECOJO').length);
  protected readonly pedidosFiltrados = computed(() => {
    const filtro = this.filtroTipo();
    return filtro === 'TODOS' ? this.pedidos() : this.pedidos().filter((p) => p.tipoEntrega === filtro);
  });

  constructor() {
    this.cargar(false);
    const id = setInterval(() => !document.hidden && this.cargar(true), REFRESCO_MS);
    inject(DestroyRef).onDestroy(() => clearInterval(id));
  }

  protected reintentar(): void {
    this.cargar(false);
  }

  protected accion(pedido: PedidoListoMostrador): void {
    if (pedido.tipoEntrega === 'DELIVERY') this.abrirAsignar(pedido);
    else this.paraEntregar.set(pedido);
  }

  protected abrirAsignar(pedido: PedidoListoMostrador): void {
    this.paraAsignar.set(pedido);
    this.motorizadoElegido.set(null);
    this.cargandoMotorizados.set(true);
    this.api
      .motorizadosDisponibles()
      .pipe(finalize(() => this.cargandoMotorizados.set(false)))
      .subscribe({ next: (lista) => this.motorizados.set(lista), error: () => this.motorizados.set([]) });
  }

  protected confirmarAsignacion(): void {
    const pedido = this.paraAsignar();
    const motorizadoId = this.motorizadoElegido();
    if (!pedido || motorizadoId === null || this.ocupado()) return;
    this.ocupado.set(true);
    this.api
      .asignarMotorizado(pedido.id, { motorizadoId })
      .pipe(finalize(() => this.ocupado.set(false)))
      .subscribe({
        next: (entrega) => {
          this.paraAsignar.set(null);
          this.toast.success('Motorizado asignado', `${pedido.codigo} sale con ${entrega.motorizadoNombre ?? 'el motorizado'}.`);
          this.cargar(true);
        },
        error: () => this.cargar(true),
      });
  }

  protected confirmarEntrega(): void {
    const pedido = this.paraEntregar();
    if (!pedido || this.ocupado()) return;
    this.ocupado.set(true);
    this.api
      .entregarEnMostrador(pedido.id)
      .pipe(finalize(() => this.ocupado.set(false)))
      .subscribe({
        next: () => {
          this.paraEntregar.set(null);
          this.datos.update((l) => l.filter((p) => p.pedidoId !== pedido.id));
          this.toast.success('Pedido entregado', `${pedido.codigo} se entregó en el mostrador.`);
        },
        error: () => this.cargar(true),
      });
  }

  protected cerrarModales(): void {
    if (this.ocupado()) return;
    this.paraAsignar.set(null);
    this.paraEntregar.set(null);
  }

  private cargar(silencioso: boolean): void {
    this.api
      .pedidosListos(silencioso ? { context: peticionSilenciosa() } : undefined)
      .pipe(finalize(() => this.cargando.set(false)))
      .subscribe({
        next: (lista) => {
          this.datos.set(lista);
          this.sinConexion.set(false);
        },
        error: () => this.sinConexion.set(true),
      });
  }
}

function aFila(p: PedidoListoResponse): PedidoListoMostrador {
  const delivery = p.tipoEntrega === 'DELIVERY';
  return {
    id: p.pedidoId,
    numero: p.numero,
    codigo: `#${p.numero}`,
    horaListo: formatearHora(p.listoEn),
    tipoEntrega: p.tipoEntrega,
    clienteNombre: p.nombreCliente,
    clienteTelefono: p.telefonoCliente,
    direccionPrincipal: delivery && p.direccion ? p.direccion.direccion : 'Recojo en tienda',
    direccionReferencia: delivery && p.direccion
      ? [p.direccion.distrito, p.direccion.referencia].filter(Boolean).join(' · ')
      : p.vencimientoRecojo
        ? `Lo guardamos hasta las ${formatearHora(p.vencimientoRecojo)}`
        : `A nombre de ${p.nombreCliente.split(' ')[0]}`,
    productos: (p.items ?? []).map((i) => ({ cantidad: i.cantidad, nombre: i.nombre })),
    estadoEntrega: p.estadoEntrega,
    motorizadoNombre: p.motorizadoNombre,
  };
}

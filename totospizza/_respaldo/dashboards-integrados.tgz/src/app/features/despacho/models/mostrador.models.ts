import type { EstadoEntrega, TipoEntrega } from '../../../core/models/api';

export interface ProductoMostradorItem {
  readonly cantidad: number;
  readonly nombre: string;
}

/** Fila del mostrador (sale de PedidoListoResponse del backend). */
export interface PedidoListoMostrador {
  readonly id: number;
  readonly codigo: string;
  readonly numero: string;
  readonly horaListo: string;
  readonly tipoEntrega: TipoEntrega;
  readonly clienteNombre: string;
  readonly clienteTelefono: string | null;
  readonly direccionPrincipal: string;
  readonly direccionReferencia: string;
  readonly productos: readonly ProductoMostradorItem[];
  readonly estadoEntrega: EstadoEntrega | null;
  readonly motorizadoNombre: string | null;
}

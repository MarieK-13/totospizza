import { ChangeDetectionStrategy, Component, DestroyRef, computed, inject, signal } from '@angular/core';
import { DecimalPipe } from '@angular/common';
import { finalize } from 'rxjs';
import { peticionSilenciosa } from '../../../core/interceptors/http-context';
import type { TableroCocinaResponse, TicketCocinaResponse } from '../../../core/models/api';
import { OperacionApi } from '../../../core/services/api/operacion.api';
import { ToastService } from '../../../core/services/toast.service';
import { formatearHora } from '../../../core/utils/fechas';
import type { PedidoCocina, PedidoListoCocina, ProductoCocinaItem } from '../models/cocina.models';

const REFRESCO_MS = 15_000;
const TIEMPO_HORNO_MIN = 10;
/** Cuánto tiempo se queda una pizza en la columna "Listas" después de marcarla. */
const VIGENCIA_LISTAS_MIN = 30;
const CLAVE_HORNO = 'toto.cocina.horno';
const CLAVE_LISTAS = 'toto.cocina.listas';

/**
 * Pantalla del pizzero. Lee el tablero del backend (por preparar y en horno), lo refresca cada 15 s
 * y avanza cada pedido: meter al horno → listo. Lo listo pasa al mostrador del despachador.
 */
@Component({
  selector: 'app-cocina-panel',
  imports: [DecimalPipe],
  templateUrl: './cocina-panel.component.html',
  styleUrls: ['./cocina-panel.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CocinaPanelComponent {
  private readonly api = inject(OperacionApi);
  private readonly toast = inject(ToastService);

  private readonly tablero = signal<TableroCocinaResponse | null>(null);
  private readonly ahora = signal(Date.now());
  private readonly entradasHorno = signal<Record<number, string>>(leer(CLAVE_HORNO, {}));
  private readonly listasLocales = signal<readonly PedidoListoCocina[]>(leer(CLAVE_LISTAS, []));

  protected readonly cargando = signal(true);
  protected readonly sinConexion = signal(false);
  protected readonly ocupado = signal<number | null>(null);

  protected readonly pendientes = computed(() => (this.tablero()?.porPreparar ?? []).map((t) => this.aVista(t)));
  protected readonly enHorno = computed(() => (this.tablero()?.enHorno ?? []).map((t) => this.aVista(t)));
  protected readonly listas = computed(() => {
    const limite = this.ahora() - VIGENCIA_LISTAS_MIN * 60_000;
    return this.listasLocales()
      .filter((p) => new Date(p.listoEn).getTime() >= limite)
      .map((p) => ({ ...p, hora: formatearHora(p.listoEn), minutosDesdeListo: minutosDesde(p.listoEn, this.ahora()) }));
  });
  protected readonly totalEnCocina = computed(() => this.pendientes().length + this.enHorno().length);

  constructor() {
    this.cargar(false);
    const refresco = setInterval(() => !document.hidden && this.cargar(true), REFRESCO_MS);
    const reloj = setInterval(() => this.ahora.set(Date.now()), 30_000);
    inject(DestroyRef).onDestroy(() => {
      clearInterval(refresco);
      clearInterval(reloj);
    });
  }

  protected meterAlHorno(pedido: PedidoCocina): void {
    if (this.ocupado() !== null) return;
    this.ocupado.set(pedido.id);
    this.api
      .enviarAlHorno(pedido.id)
      .pipe(finalize(() => this.ocupado.set(null)))
      .subscribe({
        next: (tablero) => {
          this.guardarEntradaHorno(pedido.id);
          this.tablero.set(tablero);
          this.toast.success('Al horno', `Pedido ${pedido.codigo} entró al horno.`);
        },
        error: () => this.alFallar(),
      });
  }

  protected marcarComoListo(pedido: PedidoCocina): void {
    if (this.ocupado() !== null) return;
    this.ocupado.set(pedido.id);
    this.api
      .marcarListo(pedido.id)
      .pipe(finalize(() => this.ocupado.set(null)))
      .subscribe({
        next: (tablero) => {
          this.tablero.set(tablero);
          this.registrarLista(pedido);
          this.toast.success('Pedido listo', `${pedido.codigo} pasó al mostrador.`);
        },
        error: () => this.alFallar(),
      });
  }

  protected calcularProgresoHorno(pedido: PedidoCocina): number {
    return Math.min(100, Math.round((pedido.minutosEnHorno / pedido.tiempoObjetivoMin) * 100));
  }

  protected reintentar(): void {
    this.cargar(false);
  }

  private cargar(silencioso: boolean): void {
    this.api
      .tableroCocina(silencioso ? { context: peticionSilenciosa() } : undefined)
      .pipe(finalize(() => this.cargando.set(false)))
      .subscribe({
        next: (tablero) => {
          this.tablero.set(tablero);
          this.sinConexion.set(false);
          this.ahora.set(Date.now());
        },
        error: () => this.sinConexion.set(true),
      });
  }

  private aVista(t: TicketCocinaResponse): PedidoCocina {
    const entrada = this.entradasHorno()[t.pedidoId];
    const notas = [t.instrucciones, ...t.items.map((i) => (i.notas ? `${i.nombre}: ${i.notas}` : null))].filter(Boolean);
    return {
      id: t.pedidoId,
      codigo: `#${t.numero}`,
      tipoEntrega: t.tipoEntrega,
      horaIngreso: formatearHora(t.confirmadoEn),
      minutosEspera: t.minutosTranscurridos,
      minutosEnHorno: entrada ? minutosDesde(entrada, this.ahora()) : 0,
      tiempoObjetivoMin: TIEMPO_HORNO_MIN,
      productos: t.items.map(
        (i): ProductoCocinaItem => ({
          cantidad: i.cantidad,
          nombre: i.nombre,
          detalle: [i.descripcion, ...i.adicionales].filter(Boolean).join(' · ') || null,
        }),
      ),
      notaEspecial: notas.length ? notas.join(' · ') : null,
    };
  }

  private guardarEntradaHorno(id: number): void {
    this.entradasHorno.update((m) => ({ ...m, [id]: new Date().toISOString() }));
    escribir(CLAVE_HORNO, this.entradasHorno());
  }

  private registrarLista(p: PedidoCocina): void {
    const lista: PedidoListoCocina = { id: p.id, codigo: p.codigo, tipoEntrega: p.tipoEntrega, productos: p.productos, listoEn: new Date().toISOString() };
    this.listasLocales.update((l) => [lista, ...l.filter((x) => x.id !== p.id)].slice(0, 20));
    escribir(CLAVE_LISTAS, this.listasLocales());
    this.entradasHorno.update(({ [p.id]: _, ...resto }) => resto);
    escribir(CLAVE_HORNO, this.entradasHorno());
  }

  /** El interceptor ya avisó el motivo; se recarga para mostrar el estado real. */
  private alFallar(): void {
    this.cargar(true);
  }
}

function minutosDesde(iso: string, ahora: number): number {
  return Math.max(0, Math.floor((ahora - new Date(iso).getTime()) / 60_000));
}

function leer<T>(clave: string, porDefecto: T): T {
  try {
    const valor = localStorage.getItem(clave);
    return valor ? (JSON.parse(valor) as T) : porDefecto;
  } catch {
    return porDefecto;
  }
}

function escribir(clave: string, valor: unknown): void {
  try {
    localStorage.setItem(clave, JSON.stringify(valor));
  } catch {
    // Modo privado o almacenamiento lleno: el tablero sigue funcionando sin recordar estos datos
  }
}

import type { TipoEntrega } from '../../../core/models/api';

export interface ProductoCocinaItem {
  readonly cantidad: number;
  readonly nombre: string;
  readonly detalle: string | null;
}

/** Ticket tal como se dibuja en el tablero (sale de TicketCocinaResponse del backend). */
export interface PedidoCocina {
  readonly id: number;
  readonly codigo: string;
  readonly tipoEntrega: TipoEntrega;
  readonly horaIngreso: string;
  readonly minutosEspera: number;
  readonly minutosEnHorno: number;
  readonly tiempoObjetivoMin: number;
  readonly productos: readonly ProductoCocinaItem[];
  readonly notaEspecial: string | null;
}

/** Pedido que la cocina marcó como listo en este turno (el backend ya no lo muestra en el tablero). */
export interface PedidoListoCocina {
  readonly id: number;
  readonly codigo: string;
  readonly tipoEntrega: TipoEntrega;
  readonly productos: readonly ProductoCocinaItem[];
  readonly listoEn: string;
}

import { ChangeDetectionStrategy, Component, DestroyRef, computed, inject, input, output, signal } from '@angular/core';
import { NgTemplateOutlet } from '@angular/common';
import { Router } from '@angular/router';
import { catchError, of } from 'rxjs';
import { Bell, CalendarDays, ChevronDown, ExternalLink, LogOut, LucideAngularModule, Menu } from 'lucide-angular';
import { peticionSilenciosa } from '../../core/interceptors/http-context';
import type { NotificacionResponse } from '../../core/models/api';
import { AuthService } from '../../core/services/auth.service';
import { OperacionApi } from '../../core/services/api/operacion.api';
import { PanelCabeceraService } from '../../core/services/panel-cabecera.service';
import { formatearFechaHora } from '../../core/utils/fechas';
import { ETIQUETA_ROL, iniciales } from '../../core/utils/roles';

const FECHA_BARRA = new Intl.DateTimeFormat('es-PE', {
  weekday: 'short',
  day: '2-digit',
  month: 'short',
  hour: '2-digit',
  minute: '2-digit',
  timeZone: 'America/Lima',
});
const REFRESCO_NOTIFICACIONES_MS = 60_000;

/**
 * Barra superior del panel: título de la sección, acciones de la página,
 * fecha en vivo, notificaciones del backend y menú del usuario.
 */
@Component({
  selector: 'app-topbar',
  imports: [LucideAngularModule, NgTemplateOutlet],
  templateUrl: './topbar.html',
  styleUrl: './topbar.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
  host: { '(document:click)': 'cerrarMenus()' },
})
export class Topbar {
  readonly title = input('');
  readonly subtitle = input('');
  readonly showMenuButton = input(true);
  readonly menuToggle = output<void>();

  private readonly auth = inject(AuthService);
  private readonly api = inject(OperacionApi);
  private readonly router = inject(Router);
  protected readonly cabecera = inject(PanelCabeceraService);

  protected readonly fecha = signal(FECHA_BARRA.format(new Date()));
  protected readonly noLeidas = signal(0);
  protected readonly notificaciones = signal<readonly NotificacionResponse[]>([]);
  protected readonly panelAbierto = signal(false);
  protected readonly menuAbierto = signal(false);

  protected readonly usuario = this.auth.usuario;
  protected readonly nombre = computed(() => {
    const u = this.usuario();
    return u ? `${u.nombres.split(' ')[0]} ${u.apellidos.split(' ')[0]}` : '';
  });
  protected readonly rol = computed(() => {
    const r = this.auth.rol();
    return r ? ETIQUETA_ROL[r] : '';
  });
  protected readonly iniciales = computed(() => {
    const u = this.usuario();
    return u ? iniciales(u.nombres, u.apellidos) : '';
  });

  protected readonly fechaHora = formatearFechaHora;
  protected readonly MenuIcon = Menu;
  protected readonly BellIcon = Bell;
  protected readonly CalendarIcon = CalendarDays;
  protected readonly ChevronIcon = ChevronDown;
  protected readonly LogoutIcon = LogOut;
  protected readonly SiteIcon = ExternalLink;

  constructor() {
    this.contarNoLeidas();
    const reloj = setInterval(() => this.fecha.set(FECHA_BARRA.format(new Date())), 30_000);
    const avisos = setInterval(() => this.contarNoLeidas(), REFRESCO_NOTIFICACIONES_MS);
    inject(DestroyRef).onDestroy(() => {
      clearInterval(reloj);
      clearInterval(avisos);
    });
  }

  protected alternarNotificaciones(evento: Event): void {
    evento.stopPropagation();
    this.menuAbierto.set(false);
    const abrir = !this.panelAbierto();
    this.panelAbierto.set(abrir);
    if (!abrir) return;
    this.api
      .notificaciones({ pagina: 0, tamano: 10 })
      .pipe(catchError(() => of(null)))
      .subscribe((pagina) => pagina && this.notificaciones.set(pagina.contenido));
  }

  protected leer(n: NotificacionResponse): void {
    if (n.leida) return;
    this.api.marcarNotificacionLeida(n.id).subscribe(() => {
      this.notificaciones.update((lista) => lista.map((x) => (x.id === n.id ? { ...x, leida: true } : x)));
      this.noLeidas.update((c) => Math.max(0, c - 1));
    });
  }

  protected leerTodas(): void {
    this.api.marcarTodasLeidas().subscribe(() => {
      this.notificaciones.update((lista) => lista.map((x) => ({ ...x, leida: true })));
      this.noLeidas.set(0);
    });
  }

  protected alternarMenu(evento: Event): void {
    evento.stopPropagation();
    this.panelAbierto.set(false);
    this.menuAbierto.update((v) => !v);
  }

  protected cerrarMenus(): void {
    this.panelAbierto.set(false);
    this.menuAbierto.set(false);
  }

  protected irAlSitio(): void {
    void this.router.navigateByUrl('/');
  }

  protected cerrarSesion(): void {
    this.auth.logout('/login').subscribe();
  }

  private contarNoLeidas(): void {
    this.api
      .contarNoLeidas({ context: peticionSilenciosa() })
      .pipe(catchError(() => of(null)))
      .subscribe((c) => c && this.noLeidas.set(c.total));
  }
}

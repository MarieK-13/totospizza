import { ChangeDetectionStrategy, Component, DestroyRef, computed, inject, signal } from '@angular/core';
import { toSignal } from '@angular/core/rxjs-interop';
import { ActivatedRoute, NavigationEnd, Router, RouterLink, RouterOutlet } from '@angular/router';
import { filter, map, startWith } from 'rxjs';
import { LogOut, LucideAngularModule } from 'lucide-angular';
import { AuthService } from '../../core/services/auth.service';
import { ETIQUETA_ROL } from '../../core/utils/roles';

const HORA = new Intl.DateTimeFormat('es-PE', { hour: '2-digit', minute: '2-digit', second: '2-digit', hourCycle: 'h23', timeZone: 'America/Lima' });
const FECHA = new Intl.DateTimeFormat('es-PE', { weekday: 'long', day: '2-digit', month: 'short', year: 'numeric', timeZone: 'America/Lima' });

/**
 * Layout de las pantallas operativas (cocina, despacho, reparto):
 * barra con la marca, el módulo, el turno, la hora en vivo y la salida.
 */
@Component({
  selector: 'app-staff-layout',
  imports: [RouterOutlet, RouterLink, LucideAngularModule],
  templateUrl: './staff-layout.html',
  styleUrl: './staff-layout.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class StaffLayout {
  private readonly router = inject(Router);
  private readonly route = inject(ActivatedRoute);
  private readonly auth = inject(AuthService);

  protected readonly modulo = toSignal(
    this.router.events.pipe(
      filter((e) => e instanceof NavigationEnd),
      startWith(null),
      map(() => this.datosModulo()),
    ),
    { initialValue: this.datosModulo() },
  );

  protected readonly hora = signal(HORA.format(new Date()));
  protected readonly fecha = FECHA.format(new Date());
  protected readonly persona = computed(() => {
    const u = this.auth.usuario();
    const r = this.auth.rol();
    return u ? `${u.nombres.split(' ')[0]} ${u.apellidos.split(' ')[0]}${r ? ' · ' + ETIQUETA_ROL[r] : ''}` : '';
  });
  protected readonly LogoutIcon = LogOut;

  constructor() {
    const id = setInterval(() => this.hora.set(HORA.format(new Date())), 1000);
    inject(DestroyRef).onDestroy(() => clearInterval(id));
  }

  protected cerrarSesion(): void {
    this.auth.logout('/login').subscribe();
  }

  private datosModulo(): { titulo: string; subtitulo: string } {
    let actual = this.route.snapshot;
    while (actual.firstChild) actual = actual.firstChild;
    const { data } = actual;
    return { titulo: data['titulo'] ?? 'Operación', subtitulo: data['subtitulo'] ?? '' };
  }
}
